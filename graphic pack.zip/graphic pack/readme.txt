Color
=====

background: #d6d2c4;
fontcolor: #707372;
red: #b07c83;
blue: #a4c8e1;


Fonts
=====

FixedSys: Titles, large texts
VioletSans: Copy texts
Retromoticons: Emoji shizzle